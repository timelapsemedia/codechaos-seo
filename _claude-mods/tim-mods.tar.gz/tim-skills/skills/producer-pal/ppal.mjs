#!/usr/bin/env node

// Producer Pal REST API client (Node 18+, no dependencies).
//
// CLI:
//   node ppal.mjs --add-to-live-set
//   node ppal.mjs --set-config '<json>'
//   node ppal.mjs --list-tools
//   node ppal.mjs <tool> [json-args] [options]
//
// Options:
//   --url <baseUrl>          override Producer Pal URL (default http://localhost:3350)
//   --timeout-ms <ms>        per-request timeout (1–55000)
//   --set-config <json>      update device settings, e.g. '{"liveApiEnabled":true}'
//   --notation <name>        barbeat | midi-json | stark, for this request only
//   --disable-tools <names>  withhold tools from this request (comma-separated)
//   --small-model-mode       shrink tool schemas and Skills for this request
//
// Examples:
//   node ppal.mjs --list-tools --notation midi-json
//   node ppal.mjs ppal-read-live-set
//   node ppal.mjs ppal-read-track '{"path": "t0"}'
//   node ppal.mjs ppal-create-clip '{...}' --timeout-ms 10000
//   node ppal.mjs ppal-connect --disable-tools ppal-library,ppal-create-device
//
// Library:
//   import { listTools, callTool, setConfig, addToLiveSet } from "./ppal.mjs";
//   const { result, warnings } = await callTool("ppal-read-live-set");

import { readFileSync, realpathSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const DEFAULT_BASE_URL = "http://localhost:3350";

// Three of the per-request headers. Unlike --set-config these change nothing on
// the device: each applies to the one request that carries it, so it can't move the
// chat UI or another client off its own notation or toolset. Absent ⇒ that
// client keeps the device's global setting.
const DISABLED_TOOLS_HEADER = "x-producer-pal-disabled-tools";
const NOTATION_HEADER = "x-producer-pal-notation";
const SMALL_MODEL_MODE_HEADER = "x-producer-pal-small-model-mode";

/**
 * Request headers for this call's profile, omitting whichever options are
 * absent. `disabledTools` is a string[] or a comma-separated string; `notation`
 * is "barbeat" | "midi-json" | "stark"; `smallModelMode` is a boolean.
 *
 * Nothing is remembered between requests, so pass the same options on every
 * call in a session — including the `listTools` call, so the schemas you read
 * match the notation you'll write.
 */
function profileHeaders(options = {}) {
  const names = (
    Array.isArray(options.disabledTools)
      ? options.disabledTools.join(",")
      : (options.disabledTools ?? "")
  ).trim();
  return {
    ...(names ? { [DISABLED_TOOLS_HEADER]: names } : {}),
    ...(options.notation ? { [NOTATION_HEADER]: options.notation } : {}),
    ...(options.smallModelMode != null
      ? { [SMALL_MODEL_MODE_HEADER]: String(Boolean(options.smallModelMode)) }
      : {}),
  };
}

/**
 * GET /api/tools — returns the full envelope `{tools: [...]}` as a parsed
 * object. The tool list endpoint always returns JSON; it has no `?format`
 * toggle. The profile options (see profileHeaders) shape the catalog: withheld
 * tools are omitted, and the descriptions and schemas resolve against this
 * request's notation and small-model mode.
 */
export async function listTools(baseUrl = DEFAULT_BASE_URL, options = {}) {
  const res = await fetch(`${baseUrl}/api/tools`, {
    headers: profileHeaders(options),
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

/**
 * Call a Producer Pal tool by name. The REST API defaults to `format=json`, so
 * `result` is a parsed value (object/array/etc.) and warnings are surfaced as a
 * separate `warnings: string[]` field.
 *
 * The profile options (see profileHeaders) apply to this request: a withheld
 * tool 404s, `ppal-connect` returns a Skills blob matching this request's
 * notation and toolset, and `notation` also decides how notes in the arguments
 * are parsed and how notes in the result are formatted.
 */
export async function callTool(name, args = {}, options = {}) {
  const baseUrl = options.baseUrl ?? DEFAULT_BASE_URL;
  const params = new URLSearchParams();
  if (options.timeoutMs != null) {
    params.set("timeoutMs", String(options.timeoutMs));
  }

  const query = params.toString();
  const url = query
    ? `${baseUrl}/api/tools/${name}?${query}`
    : `${baseUrl}/api/tools/${name}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...profileHeaders(options),
    },
    body: JSON.stringify(args),
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

/**
 * POST /config — update device settings remotely and return the full updated
 * config. `patch` is a partial object; unrecognized keys are ignored. A wrong
 * type (e.g. the string "false" for a boolean) or an invalid value (an unknown
 * `notation`, a bad `tools` list) is a 400 that names every bad field, and
 * nothing in the patch is applied.
 *
 * Every setting here is GLOBAL to the device — it also moves the chat UI and any
 * connected MCP clients. Prefer the per-request `notation`, `disabledTools`, and
 * `smallModelMode` options for anything they cover. What's left that only lives
 * here: `{ liveApiEnabled: true }` to turn on the advanced `ppal-live-api` tool.
 */
export async function setConfig(patch, options = {}) {
  const baseUrl = options.baseUrl ?? DEFAULT_BASE_URL;
  const res = await fetch(`${baseUrl}/config`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

const REMOTE_SCRIPT_GUIDE = "https://producer-pal.org/guide/remote-script";
const ADD_WAIT_MS = 30_000;
// Live can re-create the device right after a load, so one answer can be the
// old device's last. Two in a row counts as up.
const READY_STREAK = 2;

// Ports to try: PPAL_REMOTE_SCRIPT_PORT alone if valid, else 3349 first (never
// follow the file to another Live), then the port in ~/.producer-pal's file.
function remoteScriptPorts() {
  const raw = process.env.PPAL_REMOTE_SCRIPT_PORT;
  const fromEnv = raw == null || raw.trim() === "" ? Number.NaN : Number(raw);
  if (Number.isInteger(fromEnv) && fromEnv >= 0) {
    return [fromEnv];
  }
  const ports = [3349];
  try {
    const text = readFileSync(
      join(homedir(), ".producer-pal", "remote-script-port.txt"),
      "utf8",
    ).trim();
    const port = /^\d+$/.test(text) ? Number(text) : Number.NaN;
    if (port >= 1 && port <= 65535 && port !== 3349) {
      ports.push(port);
    }
  } catch {
    // No file: an older script, which is on 3349.
  }
  return ports;
}

/**
 * Whether our remote script (not some other program) answers on `port`. A slow
 * ping counts: Live is busy, not absent, and it may be this Live's script.
 */
async function isRemoteScript(port) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/ping`, {
      signal: AbortSignal.timeout(2000),
    });
    const body = await res.json();
    return res.ok && typeof body?.script_version === "string";
  } catch (err) {
    return err?.name === "TimeoutError";
  }
}

/** The base URL of the first port where the remote script answers, or null. */
async function findRemoteScript() {
  for (const port of remoteScriptPorts()) {
    if (await isRemoteScript(port)) {
      return `http://127.0.0.1:${port}`;
    }
  }
  return null;
}

/**
 * Add the Producer Pal device to the open Live Set, on a new MIDI track,
 * through the Producer Pal remote script (which must be installed and selected
 * as a Control Surface in Live). Then wait for Producer Pal to answer. Does
 * nothing if it already answers. This changes the user's Set, so only do it
 * when they asked for Producer Pal.
 *
 * Resolves to `{ producerPal: true }`, plus `addedProducerPal: { trackIndex,
 * trackName }` when it added the device.
 */
export async function addToLiveSet(options = {}) {
  const baseUrl = options.baseUrl ?? DEFAULT_BASE_URL;
  if (await answers(`${baseUrl}/config`)) {
    return { producerPal: true };
  }

  const remoteScriptUrl = await findRemoteScript();
  if (remoteScriptUrl == null) {
    throw new Error(
      `The Producer Pal remote script isn't answering on port ${remoteScriptPorts().join(" or ")}. Is Live running? To install it, add the Producer Pal device to a track and click "Finish installation…" on it, click "Install" next to the remote script, then restart Live and select Producer Pal as a Control Surface (Live Settings → Tempo & MIDI): ${REMOTE_SCRIPT_GUIDE}. Set PPAL_REMOTE_SCRIPT_PORT if it uses another port.`,
    );
  }
  let res;
  try {
    res = await fetch(`${remoteScriptUrl}/load`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "mfl-device", name: "Producer_Pal" }),
      signal: AbortSignal.timeout(35_000), // the script waits up to 30s for Live
    });
  } catch (err) {
    throw new Error(
      `The Producer Pal remote script didn't reply: ${err.message}`,
      { cause: err },
    );
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(
      `Couldn't add Producer Pal: ${loadFailure(res.status, body, baseUrl)}`,
    );
  }

  const track = { trackIndex: body.track?.index, trackName: body.track?.name };
  if (!(await waitUntilUp(`${baseUrl}/config`, Date.now() + ADD_WAIT_MS))) {
    throw new Error(
      `Added the Producer_Pal device to track ${track.trackIndex} ("${track.trackName}"), but it didn't answer on ${baseUrl} within ${ADD_WAIT_MS / 1000}s. Check the device in Live.`,
    );
  }
  return { producerPal: true, addedProducerPal: track };
}

/** Explain a failed remote script /load. */
function loadFailure(status, body, baseUrl) {
  if (status === 404) {
    return "Live's browser has no Producer_Pal device. Install Producer_Pal.amxd in the User Library's Presets/MIDI Effects/Max MIDI Effect folder: https://producer-pal.org/installation#install-the-device";
  }
  if (status === 409 && body.candidates != null) {
    return `Live's browser has more than one Producer_Pal device: ${body.candidates.join(", ")}. Keep only one device named Producer_Pal there.`;
  }
  // A 409 without candidates: the Set already has one, but it didn't answer.
  if (status === 409 && body.error != null) {
    return `${body.error}. It isn't answering on ${baseUrl}: check that device.`;
  }
  return `the remote script answered ${status}: ${body.error ?? "(no error text)"}`;
}

/** Wait for `url` to answer READY_STREAK times in a row, until `deadline`. */
async function waitUntilUp(url, deadline) {
  let streak = 0;
  for (;;) {
    streak = (await answers(url)) ? streak + 1 : 0;
    if (streak >= READY_STREAK) {
      return true;
    }
    if (Date.now() >= deadline) {
      return false;
    }
    await new Promise((r) => setTimeout(r, 250));
  }
}

/** Whether a GET to `url` succeeds. */
async function answers(url) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    return res.ok;
  } catch {
    return false;
  }
}

// --- CLI ---

function parseArgs(argv) {
  const opts = { baseUrl: DEFAULT_BASE_URL, listTools: false };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--url") {
      opts.baseUrl = argv[++i];
    } else if (arg === "--timeout-ms") {
      opts.timeoutMs = Number(argv[++i]);
    } else if (arg === "--list-tools") {
      opts.listTools = true;
    } else if (arg === "--add-to-live-set") {
      opts.addToLiveSet = true;
    } else if (arg === "--set-config") {
      opts.setConfig = argv[++i];
    } else if (arg === "--disable-tools") {
      opts.disabledTools = argv[++i];
    } else if (arg === "--notation") {
      opts.notation = argv[++i];
    } else if (arg === "--small-model-mode") {
      opts.smallModelMode = true;
    } else if (arg === "--help" || arg === "-h") {
      opts.help = true;
    } else {
      positional.push(arg);
    }
  }
  return { opts, positional };
}

const HELP = `Producer Pal REST API client

Usage:
  node ppal.mjs --add-to-live-set
  node ppal.mjs --set-config '<json>'
  node ppal.mjs --list-tools
  node ppal.mjs <tool> [json-args] [options]

Options:
  --url <baseUrl>          override Producer Pal URL (default ${DEFAULT_BASE_URL})
  --timeout-ms <ms>        per-request timeout (1–55000)
  --add-to-live-set        add the Producer Pal device to the open Live Set if it
                           isn't running (needs the Producer Pal remote script)
  --set-config <json>      update device settings, e.g. '{"liveApiEnabled":true}'
                           Global to the device — it moves every other client too.
  --notation <name>        barbeat | midi-json | stark
  --disable-tools <names>  withhold tools from this request (comma-separated
                           tool names)
  --small-model-mode       shrink tool schemas and Skills
  --help, -h               show this help

--notation, --disable-tools, and --small-model-mode apply to the ONE request
that carries them. Nothing is remembered between calls, so pass them every
time, --list-tools included.

Examples:
  node ppal.mjs --list-tools --notation midi-json
  node ppal.mjs ppal-read-live-set
  node ppal.mjs ppal-read-track '{"path": "t0"}'
  node ppal.mjs ppal-create-clip '{...}' --notation midi-json
  node ppal.mjs ppal-connect --disable-tools ppal-library,ppal-create-device
`;

async function main(argv) {
  const { opts, positional } = parseArgs(argv);
  if (opts.help) {
    console.log(HELP);
    return;
  }

  if (opts.addToLiveSet) {
    console.log(JSON.stringify(await addToLiveSet(opts), null, 2));
    return;
  }

  if (opts.listTools) {
    const result = await listTools(opts.baseUrl, opts);
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (opts.setConfig != null) {
    let patch;
    try {
      patch = JSON.parse(opts.setConfig);
    } catch (err) {
      console.error(`Invalid JSON for --set-config: ${err.message}`);
      process.exit(1);
    }
    const updated = await setConfig(patch, opts);
    console.log(JSON.stringify(updated, null, 2));
    return;
  }

  const [toolName, argsJson = "{}"] = positional;
  if (!toolName) {
    console.error(
      "Missing tool name. Use --list-tools to discover tools, or pass a tool name as the first argument.",
    );
    process.exit(1);
  }

  let args;
  try {
    args = JSON.parse(argsJson);
  } catch (err) {
    console.error(`Invalid JSON for tool args: ${err.message}`);
    process.exit(1);
  }

  const response = await callTool(toolName, args, opts);
  if (response.isError) {
    console.error(`API error: ${response.result}`);
    process.exit(1);
  }
  console.log(JSON.stringify(response, null, 2));
}

// Run main() when invoked as CLI (not when imported as a library)
if (isEntryPoint()) {
  try {
    await main(process.argv.slice(2));
  } catch (err) {
    if (err.cause?.code === "ECONNREFUSED") {
      console.error(
        "Could not connect to Producer Pal. Is Ableton Live running with the Producer Pal device?",
      );
    } else {
      console.error(err.message ?? err);
    }
    process.exit(1);
  }
}

// Compare real paths: argv[1] may go through a symlink, and a file URL is
// percent-encoded (and /C:/... on Windows).
function isEntryPoint() {
  try {
    return (
      realpathSync(process.argv[1]) ===
      realpathSync(fileURLToPath(import.meta.url))
    );
  } catch {
    return false;
  }
}
